import xbmc
import xbmcaddon
import xbmcgui

import sys

from resources.lib import manage

_addon = xbmcaddon.Addon()


if __name__ == '__main__':
    labels = {'label': xbmc.getInfoLabel('ListItem.Label'),
              'path': xbmc.getInfoLabel('ListItem.FolderPath'),
              'icon': xbmc.getInfoLabel('ListItem.Icon'),
              'is_folder': xbmc.getCondVisibility('Container.ListItem.IsFolder'),
              'content': 'videos',
              'window': xbmcgui.getCurrentWindowId()}
    
    _type = manage.add_as(labels['path'], labels['is_folder'])
    if _type:
        labels['type'] = _type
        group = manage.group_dialog(_type)
        if group:
            manage.add_path_from_context(group['name'], labels)
