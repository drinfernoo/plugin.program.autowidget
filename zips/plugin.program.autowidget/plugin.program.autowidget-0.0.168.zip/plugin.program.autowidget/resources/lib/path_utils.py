import xbmc
import xbmcaddon
import xbmcgui

import ast
import os
import random
import re
import shutil
import time
import uuid

try:
    from urllib.parse import parse_qsl
except ImportError:
    from urlparse import parse_qsl

from xml.etree import ElementTree as ET
import json

from resources.lib.common import utils

_addon = xbmcaddon.Addon()
_addon_path = xbmc.translatePath(_addon.getAddonInfo('profile'))
_shortcuts = xbmcaddon.Addon('script.skinshortcuts')
_shortcuts_path = xbmc.translatePath(_shortcuts.getAddonInfo('profile'))

widget_props_pattern = '\w*[.-]*[wW]idget(\w+)[.-]*\w*'
activate_window_pattern = '[aA]ctivate[wW]indow[(]\w+,(.*)(?:,[rR]eturn)?[)]'


def add_path(group):
    _type = get_group(group)['type']
    path_def = {}
    
    widget = ('RunScript(script.skinshortcuts,'
              'type=widgets'
              '&showNone=False'
              '&skinWidget=autoWidget-{0}'
              '&skinWidgetType=autoWidgetType-{0}'
              '&skinWidgetName=autoWidgetName-{0}'
              '&skinWidgetTarget=autoWidgetTarget-{0}'
              '&skinWidgetPath=autoWidgetPath-{0})').format(group)
    
    shortcut = ('RunScript(script.skinshortcuts,'
                'type=shortcuts'
                '&custom=True'
                '&showNone=False'
                '&skinLabel=autoLabel-{0}'
                '&skinAction=autoAction-{0}'
                '&skinList=autoList-{0}'
                '&skinType=autoType-{0}'
                '&skinThumbnail=autoThumbnail-{0})').format(group)
                
    if _type == 'widget':
        path = utils.get_skin_string('autoWidgetPath-{}'.format(group))
        xbmc.executebuiltin(widget, wait=True)
        
        while path == utils.get_skin_string('autoWidgetPath-{}'.format(group)):
            time.sleep(1)
        
        path_def.update({'widget': utils.get_skin_string('autoWidget-{}'.format(group)),
                         'type': utils.get_skin_string('autoWidgetType-{}'.format(group)),
                         'name': utils.get_skin_string('autoWidgetName-{}'.format(group)),
                         'target': utils.get_skin_string('autoWidgetTarget-{}'.format(group)),
                         'path': utils.get_skin_string('autoWidgetPath-{}'.format(group))})
    elif _type == 'shortcut':
        action = utils.get_skin_string('autoAction-{}'.format(group))
        xbmc.executebuiltin(shortcut, wait=True)
        
        while action == utils.get_skin_string('autoAction-{}'.format(group)):
            time.sleep(1)
        
        path_def.update({'label': utils.get_skin_string('autoLabel-{}'.format(group)),
                         'action': utils.get_skin_string('autoAction-{}'.format(group)),
                         'list': utils.get_skin_string('autoList-{}'.format(group)),
                         'type': utils.get_skin_string('autoType-{}'.format(group)),
                         'thumbnail': utils.get_skin_string('autoThumbnail-{}'.format(group))})
                          
    filename = os.path.join(_addon_path, '{}.group'.format(group))

    with open(filename, 'r') as f:
        group_json = json.loads(f.read())
        group_json['paths'].append(path_def)
    
    with open(filename, 'w') as f:
        f.write(json.dumps(group_json))
        
    xbmc.executebuiltin('Container.Refresh()')
        
    

def get_group(group):
    for defined in find_defined_groups():
        if defined.get('name', '') == group:
            return defined
    
    
def find_defined_groups():
    groups = []
    
    for filename in [x for x in os.listdir(_addon_path) if x.endswith('group')]:
        path = os.path.join(_addon_path, filename)
        
        with open(path, 'r') as f:
            group_json = json.loads(f.read())
        
        groups.append(group_json)

    utils.log('find_defined_groups: {}'.format(groups))
    return groups
    
    
def find_defined_paths(group=None):
    paths = []
    filename = ''
        
    if group:
        filename = '{}.group'.format(group)
        path = os.path.join(_addon_path, filename)
        
        if os.path.exists(path):
            with open(path, 'r') as f:
                group_json = json.loads(f.read())
            
            return group_json['paths']
    else:
        for group in find_defined_groups():
            paths.append(find_defined_paths(group.get('name', '')))
    
    utils.log('find_defined_paths: {}'.format(paths))
    return paths
    
        
def _get_random_paths(group, force=False, change_sec=3600):
    wait_time = 5 if force else change_sec
    now = time.time()
    seed = now - (now % wait_time)
    rand = random.Random(seed)
    paths = find_defined_paths(group)
    rand.shuffle(paths)
    
    utils.log('_get_random_paths: {}'.format(paths))
    return paths
    

def add_group(_type):
    dialog = xbmcgui.Dialog()
    group = dialog.input(heading='Name for Group') or ''
    
    if group:
        filename = os.path.join(_addon_path, '{}.group'.format(group))
        group_def = {'name': group, 'type': _type, 'paths': []}
        group_json = json.dumps(group_def)
    
        with open(filename, 'w+') as f:
            f.write(group_json)
            
        xbmc.executebuiltin('Container.Refresh()')
    else:
        dialog.notification('AutoWidget', 'Cannot create a group with no name.')
    
    
def edit_group(group=None):
    if not group:
        dialog = xbmcgui.Dialog()
        group = dialog.input(heading='Name for Group') or ''
    
    if group:
        xbmc.executebuiltin('RunScript(script.skinshortcuts,type=manage'
                            '&group=autowidget-{})'.format(group), wait=True)
        # xbmc.executebuiltin('Container.Refresh()')
    else:
        dialog.notification('AutoWidget', 'Cannot create a group with no name.')
        

def remove_group(group):
    utils.ensure_addon_data()
    
    dialog = xbmcgui.Dialog()
    choice = dialog.yesno('AutoWidget', 'Are you sure you want to remove this group? This action [B]cannot[/B] be undone.')
    
    if choice:
        filename = '{}.group'.format(group).lower()
        filepath = os.path.join(_addon_path, filename)
        try:
            os.remove(filepath)
        except Exception as e:
            utils.log('{}'.format(e), level=xbmc.LOGERROR)
            
        # for file in os.listdir(_addon_path):
            # savedpath = os.path.join(_addon_path, file)
            # with open(savedpath, 'r') as f:
                # content = f.read()
            
            # if group in content:
                # try:
                    # os.remove(savedpath)
                # except Exception as e:
                    # utils.log('{}'.format(e), level=xbmc.LOGERROR)
        
        xbmc.executebuiltin('Container.Update(plugin://plugin.program.autowidget/)')
    else:
        dialog.notification('AutoWidget', 'Cannot create a group with no name.')

        
def _save_path_details(path):
    split = path.split('\"')[1].split('?')[1]
    params = dict(parse_qsl(split))
    action_param = params.get('action', '').replace('\"','')
    group_param = params.get('group', '').replace('\"','')
    id = uuid.uuid4()
    
    path_to_saved = os.path.join(_addon_path, '{}.auto'.format(id))
    
    with open(path_to_saved, "w") as f:
        content = '{},{}'.format(action_param, group_param)
        f.write(content)
    
    utils.log('_save_path_details: {}'.format(id))
    return id
                
                
def _process_widgets():
    skin = xbmc.translatePath('special://skin/')
    skin_id = os.path.basename(os.path.normpath(skin))
    props_path = os.path.join(_shortcuts_path, '{}.properties'.format(skin_id))
    
    if not os.path.exists(props_path):
        return
    
    with open(props_path, 'r') as f:
        prop_list = ast.literal_eval(f.read())
    
    convert_list = [prop for prop in prop_list
                    if all(param in prop[3] for param in
                           ['plugin.program.autowidget',
                            'mode=path', 'action=random'])]
    finished_props = [prop for prop in prop_list if prop not in convert_list]
    
    for convert in convert_list:
        menu, group = convert[0:2]
        
        _id = _save_path_details(convert[3])
        label_str = '$INFO[Skin.String(autowidget-{}-name)]'.format(_id)
        path_str = '$INFO[Skin.String(autowidget-{}-path)]'.format(_id)
        
        # fix shortcut xmls
        xml_path = os.path.join(_shortcuts_path,
                                '{}.DATA.xml'.format(menu.replace('.', '-')))
        shortcuts = ET.parse(xml_path).getroot()
        for shortcut in shortcuts.findall('shortcut'):
            action = shortcut.find('action')
            label = shortcut.find('label')
            
            if action.text.replace('&amp;', '&') in convert[3]:
                label.text = label_str
                
                if re.search(activate_window_pattern, convert[3]):
                    action.text = re.sub(activate_window_pattern, convert[3],
                                         path_str)
                
        tree = ET.ElementTree(shortcuts)
        tree.write(xml_path)
        
        # fix properties
        if re.search(activate_window_pattern, convert[3]):
            convert[3] = re.sub(activate_window_pattern, convert[3], path_str)
            
        finished_props.append(convert)
            
    with open(props_path, 'w') as f:
        f.write('{}'.format(finished_props))


def refresh_paths(notify=False, force=False):
    processed = 0
    utils.ensure_addon_data()
    
    if notify:
        dialog = xbmcgui.Dialog()
        dialog.notification('AutoWidget', 'Refreshing AutoWidgets')
    
    if force:
        _process_widgets()
        xbmc.executebuiltin('ReloadSkin()')
    
    for group in find_defined_groups():
        paths = []
        
        for saved in [saved for saved in os.listdir(_addon_path)
                      if saved.endswith('.auto')]:
            saved_path = os.path.join(_addon_path, saved)
            with open(saved_path, 'r') as f:
                params = f.read().split(',')
                
            action = params[0]
            group_param = params[1]
            
            if group_param != group:
                continue
                
            _id = os.path.basename(saved_path)[:-5]
            skin_path = 'autowidget-{}-path'.format(_id)
            skin_label = 'autowidget-{}-name'.format(_id)
        
            if action == 'random' and len(paths) == 0:
                paths = _get_random_paths(group, force)
        
            if len(paths) > 0:
                path = paths.pop()
                xbmc.executebuiltin('Skin.SetString({},{})'.format(skin_label,
                                                                   path[0]))
                xbmc.executebuiltin('Skin.SetString({},{})'
                                .format(skin_path, path[2].replace('\"','')))
                utils.log('{}: {}'.format(skin_label, path[0]))
                utils.log('{}: {}'.format(skin_path, path[2].replace('\"','')))
                processed += 1
